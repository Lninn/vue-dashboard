module.exports = {
  singleQuote: true,
  semi: false,
  trailingComma: true,
}
