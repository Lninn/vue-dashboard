<template>
  <div style="text-align: center;">
    <IconFont type="icon-icon-404" style="font-size: 100px" />
    <Logo />
  </div>
</template>

<script>
import Logo from '@/assets/logo.svg'

export default {
  components: {
    Logo,
  },
}
</script>

<style></style>
