const getters = {
  roles: state => state.roles,
}

export default getters
